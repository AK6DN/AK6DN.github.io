#!/bin/bash -x
cp ../../../boards_and_stuff/rx02_emulator/rx02_emulator_github/disk_images/RT11.RX1 RX0.DSK
cp ../../../boards_and_stuff/rx02_emulator/rx02_emulator_github/disk_images/RT11.RX1 RX1.DSK
pdp11 rx01bo.ini
