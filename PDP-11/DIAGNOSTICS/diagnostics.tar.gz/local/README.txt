
Diagnostic Programs
-------------------

dl11.mac - simple diagnostic test of a DL11 serial interface card
m9313.mac - simple diagnostic test using the M9313 UET (Unibus Exerciser Terminator) card
memx.mac - comprehensive memory tester
mscp.mac - simple interface diagnostic of an MSCP disk interface
tmscp.mac - simple interface diagnostic of a TMSCP tape interface

Test Programs
-------------

divtst.mac - table driven DIV instruction tester
prftst.mac - test of printf subroutine implementation

Support
-------

Makefile - make command to generate listing and binaries of each program

Files
-----

*.ini - setup files for SIMH test of the program
*.mac - PDP-11 macro source
*.obj - PDP-11 assembled object file
*.lst - PDP-11 assembled listing file
*.bin - PDP-11 binary absolute loader of an assembled .obj file
*.bic - PDP-11 binary absolute loader of an assembled .obj file, XXDP chainable
*.dmp - 'dumpobj' debug output of an assembled .obj to .bin file translation
*.log - 'obj2hex' debug output of an assembled .obj to .bin file tranalation

